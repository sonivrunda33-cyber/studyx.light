import {toast} from '../core/ui.js';
import {setProfile} from '../core/utils.js';

export function init(){
  const form=document.querySelector('#profileForm');
  const name=document.body.dataset.accountName||'Student';
  const goal=localStorage.getItem('luma-weekly-goal')||'12';
  document.querySelector('#settingName').value=name;document.querySelector('#settingGoal').value=goal;
  const reminder=document.querySelector('#reminderToggle');reminder.checked=localStorage.getItem('luma-reminders')==='true';
  form?.addEventListener('submit',event=>{event.preventDefault();const newGoal=Math.max(1,Math.min(100,Number(form.elements.goal.value)||12));localStorage.setItem('luma-weekly-goal',String(newGoal));setProfile(name);toast('Weekly study goal saved in this browser')});
  reminder?.addEventListener('change',()=>{localStorage.setItem('luma-reminders',String(reminder.checked));toast(reminder.checked?'In-app reminder preference enabled':'In-app reminder preference disabled')});
}
